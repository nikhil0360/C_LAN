#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int strend(char *s1,char *s2)
{
	for(int i=0;i<strlen(s2);i++)
	{
		if(s2[strlen(s2)-i]!=s1[strlen(s1)-i])
		{
			printf("0");
			return 0;
		}
	}
	printf("%s",s2);
	return 0;
}
int main()
{
	char *a=malloc(256*sizeof(char));
	char *b=malloc(256*sizeof(char));
	scanf("%s",a);
	scanf("%s",b);
	strend(a,b);
	free(a);
	free(b);
	return 0;
}

