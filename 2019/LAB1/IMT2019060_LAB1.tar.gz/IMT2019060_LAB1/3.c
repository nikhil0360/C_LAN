#include <stdio.h>

int main()
{
double c , f ;
scanf( "%lf", &c ) ;
f = (1.8*c) + 32 ;
printf("%.2lf" , f ) ;
}
